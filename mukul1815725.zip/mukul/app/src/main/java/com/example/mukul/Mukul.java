
package com.example.mukul;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.lang.reflect.Array;

public class Mukul extends AppCompatActivity {
    private void launchActivity() {

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public double getvalue()
    { String value;
        double num;
      value= (String) EditText.getText();

       num=Double.valueOf(value);
        return num;
    }

    TextView EditText, TextView;
    double multiply=0.0,divide=0.0,t1=0.0,add=0.0,sub=0.0;

    String sign;
    String value1, value2;
    Double num1, num2, result;
    boolean scientific;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mukul2);

        EditText = (TextView) findViewById(R.id.EditText);
        TextView = (TextView) findViewById(R.id.sign);


        scientific = false;
    }

    public void btnClick_u(View view) {

        EditText.setText(EditText.getText() + "-" );

    }

    public void btnClick_0(View view) {
        EditText.setText(EditText.getText() + "0");
    }

    public void btnClick_1(View view) {
        EditText.setText(EditText.getText() + "1");
    }


    public void btnClick_2(View view) {
        EditText.setText(EditText.getText() + "2");
    }


    public void btnClick_3(View view) {
        EditText.setText(EditText.getText() + "3");
    }


    public void btnClick_4(View view) {
        EditText.setText(EditText.getText() + "4");
    }


    public void btnClick_5(View view) {
        EditText.setText(EditText.getText() + "5");
    }


    public void btnClick_6(View view) {
        EditText.setText(EditText.getText() + "6");
    }


    public void btnClick_7(View view) {
        EditText.setText(EditText.getText() + "7");
    }


    public void btnClick_8(View view) {
        EditText.setText(EditText.getText() + "8");
    }


    public void btnClick_9(View view) {
        EditText.setText(EditText.getText() + "9");
    }



    public void btnClick_dot(View view) {
            EditText.setText(".");

    }
    public void btnClick_N(View view) {
      launchActivity();
    }





    public void btnClick_clear(View view) {
        EditText.setText(null);
        TextView.setText(null);
        value1 = null;
        value1 = null;

    }

    public void btnClick_add(View view) {
        try{          num1=getvalue();
            sign="+";
            EditText.setText("");
            if(sub>=1||multiply>=1||divide>=1)
            {    if(sub>=1)
                num1=t1-num1;
            else if(multiply>=1)
                num1=num1*t1;
            else
                num1=t1/num1;

            }
            add++;
            sub=0.0;
            multiply=0.0;
            divide=0.0;
            if(add==1)
            {
                t1=num1;
            }
            else
                num1=num1+t1;
            t1=num1;
            TextView.setText("+");
        }
        catch(Exception e){
            TextView.setText("Error"); value1=null;
            value2=null;
            num1=0.0;

            num2=0.0;
            TextView.setText("+");

        }
    }

    public void btnClick_subtract(View view) {
        try{   sign = "-";
            num1=getvalue();
            EditText.setText("");
            if(add>=1||multiply>=1||divide>=1)
            {   if(add>=1)
                num1=t1+num1;
            else if(multiply>=1)
                num1=num1*t1;
            else
                num1=t1/num1;

            }
            add=0.0;
            sub++;
            multiply=0.0;
            divide=0.0;
            if(sub==1)
            {
                t1=num1;
            }
            else
                num1=t1-num1;
            t1=num1;

            TextView.setText("-");
        }catch(Exception e){
            TextView.setText("Error");
            value1=null;value2=null;
            num1=0.0;

            num2=0.0;
            TextView.setText("-");
        }}

    public void btnClick_multiply(View view) {
        try{ sign = "*";
            num1 = getvalue();
            EditText.setText("");
            if (sub >= 1 || add >= 1 || divide >= 1) {
                if (add >= 1)
                    num1 = num1 + t1;
                else if (sub >= 1)
                    num1 = t1 - num1;
                else
                    num1 = t1 / num1;
            }
            add = 0.0;
            sub = 0.0;
            multiply++;
            divide = 0.0;
            if (multiply == 1) {
                t1 = num1;
            } else
                num1 = num1 * t1;
            t1=num1;


            TextView.setText("×");
        }catch(Exception e){ value1=null;  value1=null;
            value2=null;
            num1=0.0;

            num2=0.0;
            TextView.setText("*");
        }}

    public void btnClick_divide(View view) {
        try{sign = "/";
            num1=getvalue();
            EditText.setText("");
            if(sub>=1||multiply>=1||add>=1)
            {   if(add>=1)
                num1=t1+num1;
            else if(sub>=1)
                num1=t1-num1;
            else if(multiply>=1)
                num1=num1*t1;
            }
            add=0.0;
            sub=0.0;
            multiply=0.0;
            divide++;
            if(divide==1)
            {
                t1=num1;
            }
            else
                num1=t1/num1;

            t1=num1;

            TextView.setText("÷");
        }catch(Exception e){  value1=null; value1=null;
            value2=null;
            num1=0.0;

            num2=0.0;
            TextView.setText("/");
        }}

    public void btnClick_sin(View view) {

        try {

            TextView.setText("sin");

            EditText.setText(Double.toString(Math.sin(getvalue())));
        } catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;

        }
    }
    public void btnClick_cos(View view) {
        try{
        value1 = EditText.getText().toString();
        num1 = Double.parseDouble((value1));
        EditText.setText(Math.cos(num1) + "");
        TextView.setText("cos");
    }catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;

        }}
    public void btn_clickc(View view) {
        try {

            String a = EditText.getText().toString();

            EditText.setText("");
            int m = a.length() - 1;
            String val = a.substring(0, m);
            EditText.setText(val.toString());
        } catch (Exception e) {
            TextView.setText("Nothing ");
        }
    }



    public void btnClick_tan(View view) {try{
        value1 = EditText.getText().toString();
        num1 = Double.parseDouble((value1));
        EditText.setText(Math.cos(num1) + "");


        TextView.setText("tan");
    }catch (Exception e) {
        TextView.setText("Error");
        value1 = null;
        value2 = null;
        num1 = 0.0;
        num2 = 0.0;

    }}

    public void btnClick_root(View view) {
        try {

            EditText.setText(Double.toString(Math.sqrt(getvalue())) );
            TextView.setText("root");

            TextView.setText("√");
        } catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;

        }
    }

    public void btnClick_log(View view) {
        try {
            scientific = true;
            value1 = EditText.getText().toString();
            num1 = Double.parseDouble((value1));
            EditText.setText(Math.log10(num1) + "");


            TextView.setText("log");
        } catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;

        }
    }

    public void btnClick_ln(View view) {
        try{
        value1 = EditText.getText().toString();
        num1 = Double.parseDouble((value1));
        EditText.setText(Math.log(num1) + "");



        TextView.setText("ln");
    }catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;

        }
    }

    public void btnClick_power(View view) {
        scientific = true;
        sign = "power";
        value1 = EditText.getText().toString();
        EditText.setText(null);

        TextView.setText("xⁿ");
    }


    public void btnClick_equal(View view) {
        try {   num2=getvalue();
                switch (sign) {
                    default:
                        break;

                    case "+":
                        try {
                            if(add>0)
                            {   add=0.0;
                                result=num1+num2;
                                EditText.setText(Double.toString(result));
                                sign = null;
                            }

                            TextView.setText(null);
                            break;}
                        catch (Exception e){   TextView.setText("Error");
                            value1=null;
                            value2=null;
                            num1=0.0;
                            num2=0.0;

                        }



                    case "-":
                        try {
                            if (sub > 0) {
                                sub = 0.0;
                                result = num1 - num2;
                                EditText.setText(Double.toString(result));
                            }


                            TextView.setText(null);
                            break;
                        } catch (Exception e) {
                            TextView.setText("Error");
                            value1 = null;
                            value2 = null;
                            num1 = 0.0;
                            num2 = 0.0;

                        }
                    case "*":
                        try {
                            if (multiply > 0) {
                                multiply = 0.0;
                                result = num1 * num2;
                                EditText.setText(Double.toString(result));
                            }

                            TextView.setText(null);
                            break;
                        } catch (Exception e) {
                            TextView.setText("Error");
                            value1 = null;
                            value2 = null;
                            num1 = 0.0;
                            num2 = 0.0;

                        }
                    case "/":
                        try {

                            if (divide > 0) {
                                divide = 0.0;
                                result = num1 / num2;
                                EditText.setText(Double.toString(result));

                            }

                            TextView.setText(null);
                            break;
                        } catch (Exception e) {
                            TextView.setText("Error");
                            value1 = null;
                            value2 = null;
                            num1 = 0.0;
                            num2 = 0.0;

                        }
                    case "power":
                        num1 = Double.parseDouble((value1));
                        value2 = EditText.getText().toString();
                        num2 = Double.parseDouble(value2);

                        EditText.setText(Math.pow(num1, num2) + "");

                        sign = null;
                        scientific = false;
                        TextView.setText(null);
                        break;
                }



        } catch (Exception e) {
            TextView.setText("Error");
            value1 = null;
            value2 = null;
            num1 = 0.0;
            num2 = 0.0;
        }

    }

}

