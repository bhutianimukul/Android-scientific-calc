package com.example.mukul;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Welcome extends AppCompatActivity {

    TextView t1,t2;

    private void launchActivity(){

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        Handler h= new Handler();

        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                launchActivity();

            }
        },2000);




        t1 = (TextView) findViewById(R.id.textView1);

        t1 = (TextView) findViewById(R.id.textView2);



        }
 }
